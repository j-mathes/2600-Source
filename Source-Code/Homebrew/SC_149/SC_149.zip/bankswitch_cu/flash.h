/*****************************************************************************
Melody Driver - (C) Chris Walton 2012
File: flash.h
Description: Dummy Flash Functions
******************************************************************************/

#ifndef FLASH_H
#define FLASH_H

// Flash Entry Point
extern void FLASH_Main(void);

#endif // FLASH_H
